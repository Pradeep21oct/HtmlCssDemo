/**
 * 
 */
define('module_one', function(){
    return 'Hello. I am module one';
})

define('module_two', function(){
    return 'Hello. I am module two';
})

/*

define('module1', ['dependency1', 'dependency2'], function (d1, d2) {
    // your code here
}*/